// ('#ratingSelect').change(function()=>{
//
//   //
//   // window.location.href = "/feedback";
//   // '/feedback'
//   //
//
//   $("#ratingSelect").val();
// });
