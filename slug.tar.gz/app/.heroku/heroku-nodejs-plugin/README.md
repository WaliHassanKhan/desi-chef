# Heroku Node.js Metrics Plugin

This is a Node plugin that plugs into libuv and v8 in your Node process
and submits those metrics to Heroku. It is automatically required by your
Node process when you turn on Node Runtime Metrics.

Docs: https://devcenter.heroku.com/articles/language-runtime-metrics
Code: https://github.com/heroku/heroku-nodejs-plugin
